class WelcomeController < ApplicationController
  def homepage
  end
end
